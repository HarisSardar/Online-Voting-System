package onlinevotingsystem;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;

import javax.swing.*;
public class OnlineVotingSystem extends JFrame implements ActionListener{
   
    OnlineVotingSystem(){
    setBounds(0,0,1600,700);
    getContentPane().setBackground(Color.WHITE);
    
    JLabel l1 = new JLabel("Welcome ");
    l1.setFont(new Font("Tahoma",Font.BOLD,50));
    l1.setBounds(250,230,300,100);
    add(l1);
    JLabel l2 = new JLabel("To Online Voting System");
    l2.setFont(new Font("Tahoma",Font.BOLD,50));
    l2.setBounds(50,300,700,100);
    add(l2);
    
    ImageIcon il = new ImageIcon (ClassLoader.getSystemResource ("onlinevotingsystem/icons/votingsystem.png"));
    Image i2=il.getImage().getScaledInstance(500,300,Image.SCALE_DEFAULT);
    ImageIcon i3 = new ImageIcon(i2);
    JLabel l3 = new JLabel (i3);
    l3.setBounds(700,200,500,300);
    add(l3);
    JButton bl =new JButton ("Next");
    bl.setFont(new Font ("Tahoma", Font.PLAIN, 20));
    bl.addActionListener(this);
    bl.setBounds (250, 500, 300, 80);
    add(bl);
    
    setLayout(null);
    setVisible(true);
    }

public static void main(String[] args){
        OnlineVotingSystem onlineVotingSystem = new OnlineVotingSystem();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
			new VotingPage().setVisible(true);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			System.out.println(e1);// show database error
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			System.out.println(e1);
		}
        
    }
}
