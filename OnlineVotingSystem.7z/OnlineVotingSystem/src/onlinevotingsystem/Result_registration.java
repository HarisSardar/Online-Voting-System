package onlinevotingsystem;

import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Result_registration extends JFrame implements ActionListener {

	String a, b, c, d, g, f;
	JTextField tf6, tf7, tf8;
	JTextField tf1, tf2, tf3, tf4;
	HashMap<String, String> results = null;

	public Result_registration() {

		JLabel label1, label2, label3, label4, label5, label6, label7, label8, label9, label10, label11, label12,
				label13;
		label1 = new JLabel("Candidate Result Form");
		label1.setFont(new Font("", Font.BOLD, 20));
		label1.setBounds(150, 30, 300, 30);
		try {
			results = new HashMap<>();
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:5555/test1", "root", "12345");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select position , result from candidate_registration;");
			while (rs.next()) {
				if (rs.getString("position").equals("Chancellor")) {
					results.put("a", rs.getString("result"));
				}
				if (rs.getString("position").equals("Chairman")) {
					results.put("b", rs.getString("result"));
				}
				if (rs.getString("position").equals("Associate Chairman")) {
					results.put("c", rs.getString("result"));
				}
				if (rs.getString("position").equals("Chairperson")) {
					results.put("d", rs.getString("result"));
				}
				if (rs.getString("position").equals("Dean")) {
					results.put("g", rs.getString("result"));
				}
				if (rs.getString("position").equals("Coordinator")) {
					results.put("f", rs.getString("result"));
				}
			}
			a = results.get("a");
			System.out.println(a);
			b = results.get("b");
			System.out.println(b);
			c = results.get("c");
			System.out.println(c);
			d = results.get("d");
			System.out.println(d);
			g = results.get("g");
			System.out.println(g);
			f = results.get("f");
			System.out.println(f);

		} catch (Exception exp) {
			System.out.println(exp);
		}

		label2 = new JLabel("Chancellor:");
		label2.setBounds(150, 50, 200, 100);

		label3 = new JLabel("Chairman:");
		label3.setBounds(150, 100, 200, 100);

		label4 = new JLabel("Associate Chairman:");
		label4.setBounds(150, 150, 200, 100);

		label5 = new JLabel("Chairperson:");
		label5.setBounds(150, 200, 200, 100);

		label6 = new JLabel("Dean:");
		label6.setBounds(150, 250, 200, 100);

		label7 = new JLabel("Coordinator:");
		label7.setBounds(150, 300, 200, 100);

		label8 = new JLabel(a);
		label8.setBounds(300, 50, 200, 100);

		label9 = new JLabel(b);
		label9.setBounds(300, 100, 200, 100);

		label10 = new JLabel(c);
		label10.setBounds(300, 150, 200, 100);

		label11 = new JLabel(d);
		label11.setBounds(300, 200, 200, 100);

		label12 = new JLabel(g);
		label12.setBounds(300, 250, 200, 100);

		label13 = new JLabel(f);
		label13.setBounds(300, 300, 200, 100);

		add(label1);
		add(label2);
		add(label3);
		add(label4);
		add(label5);
		add(label6);
		add(label7);
		add(label8);
		add(label9);
		add(label10);
		add(label11);
		add(label12);
		add(label13);

		setSize(450, 500);
		setLayout(null);
		setVisible(true);
		setSize(500, 500);
		setLayout(null);
		setVisible(true);

	}

	public static void main(String args[]) {
		Result_registration result = new Result_registration();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		new Result_registration().setVisible(true);

	}
}
