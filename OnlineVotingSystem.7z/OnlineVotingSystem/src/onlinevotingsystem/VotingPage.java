package onlinevotingsystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

public class VotingPage extends JFrame implements ActionListener {
	JButton b1, b2, b3, b4, b5, b6, b7, b8, b9;
	int a, b, c, d, g, f;

	VotingPage() throws SQLException, ClassNotFoundException {

		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("onlinevotingsystem/icons/ballot.png"));
		Image i2 = i1.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
		ImageIcon i3 = new ImageIcon(i2);
		JLabel l1 = new JLabel(i3);
		l1.setBounds(50, 50, 300, 200);
		add(l1);

		ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("onlinevotingsystem/icons/ballot1.png"));
		Image i5 = i4.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
		ImageIcon i6 = new ImageIcon(i5);
		JLabel l2 = new JLabel(i6);
		l2.setBounds(350, 50, 300, 200);
		add(l2);

		ImageIcon i7 = new ImageIcon(ClassLoader.getSystemResource("onlinevotingsystem/icons/ballot2.png"));
		Image i8 = i7.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
		ImageIcon i9 = new ImageIcon(i8);
		JLabel l3 = new JLabel(i9);
		l3.setBounds(650, 50, 300, 200);
		add(l3);

		ImageIcon i10 = new ImageIcon(ClassLoader.getSystemResource("onlinevotingsystem/icons/ballot3.png"));
		Image i11 = i10.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
		ImageIcon i12 = new ImageIcon(i11);
		JLabel l4 = new JLabel(i12);
		l4.setBounds(50, 350, 300, 200);
		add(l4);

		ImageIcon i13 = new ImageIcon(ClassLoader.getSystemResource("onlinevotingsystem/icons/ballot4.png"));
		Image i14 = i13.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
		ImageIcon i15 = new ImageIcon(i14);
		JLabel l5 = new JLabel(i15);
		l5.setBounds(350, 350, 300, 200);
		add(l5);

		ImageIcon i16 = new ImageIcon(ClassLoader.getSystemResource("onlinevotingsystem/icons/ballot5.png"));
		Image i17 = i16.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
		ImageIcon i18 = new ImageIcon(i17);
		JLabel l6 = new JLabel(i18);
		l6.setBounds(650, 350, 300, 200);
		add(l6);

		b1 = new JButton("Chancellor");
		b1.addActionListener(this);
		b1.setBounds(120, 260, 150, 50);
		add(b1);

		b2 = new JButton("Chairman");
		b2.addActionListener(this);
		b2.setBounds(420, 260, 150, 50);
		add(b2);

		b3 = new JButton("Associate Chairman");
		b3.addActionListener(this);
		b3.setBounds(720, 260, 150, 50);
		add(b3);

		b4 = new JButton("Chairperson");
		b4.addActionListener(this);
		b4.setBounds(120, 550, 150, 50);
		add(b4);

		b5 = new JButton("Dean");
		b5.addActionListener(this);
		b5.setBounds(420, 550, 150, 50);
		add(b5);

		b6 = new JButton("Coordinator");
		b6.addActionListener(this);
		b6.setBounds(720, 550, 150, 50);
		add(b6);

		b7 = new JButton("Register as a Candidate");
		b7.addActionListener(this);
		b7.setBounds(1000, 260, 210, 50);
		add(b7);

		b8 = new JButton("Register as a Voter");
		b8.addActionListener(this);
		b8.setBounds(1000, 350, 210, 50);
		add(b8);

		b9 = new JButton("Results");
		b9.addActionListener(this);
		b9.setBounds(1000, 440, 210, 50);
		add(b9);

		setBounds(0, 0, 1600, 700);
		setLayout(null);
		getContentPane().setBackground(Color.WHITE);
		setVisible(true);

//		Class.forName("com.mysql.cj.jdbc.Driver");
//		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:5555/test1", "root", "12345");
//		Statement stmt = con.createStatement();
//		ResultSet rs = stmt.executeQuery("select position , result from candidate_registration;");
//		while (rs.next()) {
//			//if (rs.getString("position").equals("Chancellor")) {
//				a = rs.getInt("result");
//				System.out.println(a);
//		//	}
//			if (rs.getString("position").equals("Chairman")) {
//				b = rs.getInt("result");
//				System.out.println(b);
//			}
//			if (rs.getString("position").equals("Associate Chairman")) {
//				c = rs.getInt("result");
//				System.out.println(c);
//			}
//			if (rs.getString("position").equals("Chairperson")) {
//				d = rs.getInt("result");
//				System.out.println(d);
//			}
//			if (rs.getString("position").equals("Dean")) {
//				g = rs.getInt("result");
//				System.out.println(g);
//			}
//			if (rs.getString("position").equals("Coordinator")) {
//				f = rs.getInt("result");
//				System.out.println(f);
//			}
//		}
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		VotingPage votingPage = new VotingPage();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
//		Connection con = null;
//		PreparedStatement ps = null;
		try {
			HashMap<String, String> results = new HashMap<String, String>();
	//		con = DriverManager.getConnection("jdbc:mysql://localhost:5555/test1", "root", "");
	//		String query = "update candidate_registration set result=? where position=? ";
	//		ps = con.prepareStatement(query);

			if (e.getSource() == b7) {
				new candidate_Registration().setVisible(true);
			}
			if (e.getSource() == b8) {
				new Voter_Registration().setVisible(true);
			}
			if (e.getSource() == b9) {
				new Result_registration().setVisible(true);
			}
			if (e.getSource() == b1) {
			new chancelor_candidate().setVisible(true);
				//	a = a + 1;
			//	results.put("a", (Integer.toString(a)));
			//	results.put("chancellor", "Chancellor");
			//	ps.setInt(1, Integer.parseInt(results.get("a")));
			//	ps.setString(2, results.get("chancellor"));
			//	ps.executeUpdate();
			//	JOptionPane.showMessageDialog(null, "Your Vote is added to Chancellor");
			}
			if (e.getSource() == b2) {
			new chairman_candidate().setVisible(true);	
			//	b = b + 1;
			//	results.put("b", (Integer.toString(b)));
			//	results.put("chairman", "Chairman");
			//	ps.setInt(1, Integer.parseInt(results.get("b")));
			//	ps.setString(2, results.get("chairman"));
			//	ps.executeUpdate();
			//	JOptionPane.showMessageDialog(null, "Your Vote is added to Chairman");
			}
			if (e.getSource() == b3) {
			new associatechairman_candidate().setVisible(true);	
			//	c = c + 1;
			//	results.put("c", (Integer.toString(c)));
			//	results.put("associate chairman", "Associate Chairman");
			//	ps.setInt(1, Integer.parseInt(results.get("c")));
			//	ps.setString(2, results.get("associate chairman"));
			//	ps.executeUpdate();
			//	JOptionPane.showMessageDialog(null, "Your Vote is added to Associate Chairman");
			}
			if (e.getSource() == b4) {
			new chairperson_candidate().setVisible(true);	
			//	d = d + 1;
			//	results.put("d", (Integer.toString(d)));
			//	results.put("chairperson", "Chairperson");
			//	ps.setInt(1, Integer.parseInt(results.get("d")));
			//	ps.setString(2, results.get("chairperson"));
			//	ps.executeUpdate();
			//	JOptionPane.showMessageDialog(null, "Your Vote is added to Chairperson");
			}
			if (e.getSource() == b5) {
			new dean_candidate().setVisible(true);	
			//	g = g + 1;
//        System.out.println(g);
			//	results.put("g", (Integer.toString(g)));
			//	results.put("dean", "Dean");
			//	ps.setInt(1, Integer.parseInt(results.get("g")));
			//	ps.setString(2, results.get("dean"));
			//	ps.executeUpdate();
			//	JOptionPane.showMessageDialog(null, "Your Vote is added to Dean");
			}
			if (e.getSource() == b6) {
			new coordinator_candidate().setVisible(true);	
			//	f = f + 1;
			//	results.put("f", (Integer.toString(f)));
			//	results.put("coordinator", "Coordinator");
			//	ps.setInt(1, Integer.parseInt(results.get("f")));
			//	ps.setString(2, results.get("coordinator"));
			//	ps.executeUpdate();
			//	JOptionPane.showMessageDialog(null, "Your Vote is added to Coordinator");
			}
//			con.close();
		} catch (Exception exp) {
			System.out.println(exp);
		}
	}
}