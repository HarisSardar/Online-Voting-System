package onlinevotingsystem;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.*;
public class Voter_Registration extends JFrame implements ActionListener{
    JTextField tf6;
    JTextField tf1,tf2;
    public Voter_Registration(){
   
    JLabel label1,label2,label3;
    label1 = new JLabel("Voter Registration Form");
    label1.setBounds(160, 30, 300, 30);

    label2 = new JLabel("Name :");
    label2.setBounds(30, 50, 200, 100);
    
    label3 = new JLabel("Nic Number :");
    label3.setBounds(30, 100, 200, 100);
       
    
    tf1=new JTextField();
    tf1.setBounds(150,85,250,30);   

    tf2=new JTextField();
    tf2.setBounds(150,135,250,30);
    
    tf6 = new JTextField();
    tf6.setBounds(150,250,250,30);
    
    JButton button;
    button = new JButton("Registration");
    button.setBounds(150,200,120,30);
    
    button.addActionListener(this);
    
    add(label1); add(label2);add(label3);
    add(tf1);add(tf2);add(tf6);add(button);
    setSize(450,400); 
    setLayout(null); 
    setVisible(true);
    
    }
    public static void main(String[] args) {
        Voter_Registration voter_Registration = new Voter_Registration();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    	
    	int cnicLength = tf2.getText().length();
    	if(cnicLength==13) {
    		ArrayList<String> insertData = new ArrayList<String>();
            tf6.setText("Registration Confirmed");
            try {
            	System.out.println("lemnght: "+tf2.getText().length());
            	String temp = "";
            	Class.forName("com.mysql.cj.jdbc.Driver");  
            	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:5555/test1","root","12345");
            	Statement stmt=con.createStatement();  
            	ResultSet rs=stmt.executeQuery("select * from voter_registration where cnic = '"+tf2.getText()+"';");
            	while(rs.next()) {
            		temp=rs.getString("cnic");
            	}
            	if(tf2.getText().equals(temp)) {
            		JOptionPane.showMessageDialog(null,"You can't cast the vote");
            		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            	}
            	else {
            	String query = " insert into voter_registration (name, cnic) values (?, ?);";
            	PreparedStatement preparedStmt = con.prepareStatement(query);
            	insertData.add(tf1.getText());
    			insertData.add(tf2.getText());
    			preparedStmt.setString(1, insertData.get(0));
    			preparedStmt.setString(2, insertData.get(1));
                preparedStmt.execute();}
            	con.close();  
            	CnicInfo.cnic=tf2.getText();
            	//System.out.println("-> cnicn >>"+CnicInfo.cnic);
    		} catch (Exception e2) {
    		System.out.println(e2);
        }
    	}else {
    		JOptionPane.showMessageDialog(null,"Invalid CNIC number");
    	}
    	
    	
}
}

