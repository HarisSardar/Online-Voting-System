package onlinevotingsystem;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class coordinator_candidate extends JFrame implements ActionListener {
	JButton b1, b2, b3, b4, b5, b6, b7, b8, b9;
	int a, b, c, d, g, f;

	coordinator_candidate() throws SQLException, ClassNotFoundException {

		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("onlinevotingsystem/icons/ballot.png"));
		Image i2 = i1.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
		ImageIcon i3 = new ImageIcon(i2);
		JLabel l1 = new JLabel(i3);
		l1.setBounds(50, 50, 300, 200);
		add(l1);

		ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("onlinevotingsystem/icons/ballot1.png"));
		Image i5 = i4.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
		ImageIcon i6 = new ImageIcon(i5);
		JLabel l2 = new JLabel(i6);
		l2.setBounds(370, 50, 300, 200);
		add(l2);

		ImageIcon i7 = new ImageIcon(ClassLoader.getSystemResource("onlinevotingsystem/icons/ballot2.png"));
		Image i8 = i7.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
		ImageIcon i9 = new ImageIcon(i8);
		JLabel l3 = new JLabel(i9);
		l3.setBounds(370, 350, 300, 200);
		add(l3);

		ImageIcon i10 = new ImageIcon(ClassLoader.getSystemResource("onlinevotingsystem/icons/ballot3.png"));
		Image i11 = i10.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
		ImageIcon i12 = new ImageIcon(i11);
		JLabel l4 = new JLabel(i12);
		l4.setBounds(50, 350, 300, 200);
		add(l4);


		b1 = new JButton("Candidate 1");
		b1.addActionListener(this);
		b1.setBounds(120, 260, 150, 50);
		add(b1);

		b2 = new JButton("Candidate 2");
		b2.addActionListener(this);
		b2.setBounds(420, 260, 150, 50);
		add(b2);

		b3 = new JButton("Candidate 3");
		b3.addActionListener(this);
		b3.setBounds(420, 550, 150, 50);
		add(b3);

		b4 = new JButton("Candidate 4");
		b4.addActionListener(this);
		b4.setBounds(120, 550, 150, 50);
		add(b4);

	
		setBounds(0, 0, 720, 700);
		setLayout(null);
		getContentPane().setBackground(Color.WHITE);
		setVisible(true);

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:5555/test1", "root", "12345");
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select position , result from candidate_registration;");
		while (rs.next()) {
			if (rs.getString("position").equals("Candidate 1")) {
				a = rs.getInt("result");
			}
			if (rs.getString("position").equals("Candidate 2")) {
				b = rs.getInt("result");
			}
			if (rs.getString("position").equals("Candidate 3")) {
				c = rs.getInt("result");
			}
			if (rs.getString("position").equals("Candidate 4")) {
				d = rs.getInt("result");
			}
			
		}
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		VotingPage votingPage = new VotingPage();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			HashMap<String, String> results = new HashMap<String, String>();
			con = DriverManager.getConnection("jdbc:mysql://localhost:5555/test1", "root", "12345");
			String query = "update candidate_registration set result=? where position=? ";
			ps = con.prepareStatement(query);

			if (e.getSource() == b7) {
				new candidate_Registration().setVisible(true);
			}
			if (e.getSource() == b8) {
				new Voter_Registration().setVisible(true);
			}
			if (e.getSource() == b9) {
				new Result_registration().setVisible(true);
			}
			if (e.getSource() == b1) {
				a = a + 1;
				results.put("a", (Integer.toString(a)));
				results.put("chancellor", "Chancellor");
				ps.setInt(1, Integer.parseInt(results.get("a")));
				ps.setString(2, results.get("chancellor"));
				ps.executeUpdate();
				JOptionPane.showMessageDialog(null, "Your Vote is added to Chancellor");
			}
			if (e.getSource() == b2) {
				b = b + 1;
				results.put("b", (Integer.toString(b)));
				results.put("chairman", "Chairman");
				ps.setInt(1, Integer.parseInt(results.get("b")));
				ps.setString(2, results.get("chairman"));
				ps.executeUpdate();
				JOptionPane.showMessageDialog(null, "Your Vote is added to Chairman");
			}
			if (e.getSource() == b3) {
				c = c + 1;
				results.put("c", (Integer.toString(c)));
				results.put("associate chairman", "Associate Chairman");
				ps.setInt(1, Integer.parseInt(results.get("c")));
				ps.setString(2, results.get("associate chairman"));
				ps.executeUpdate();
				JOptionPane.showMessageDialog(null, "Your Vote is added to Associate Chairman");
			}
			if (e.getSource() == b4) {
				d = d + 1;
				results.put("d", (Integer.toString(d)));
				results.put("chairperson", "Chairperson");
				ps.setInt(1, Integer.parseInt(results.get("d")));
				ps.setString(2, results.get("chairperson"));
				ps.executeUpdate();
				JOptionPane.showMessageDialog(null, "Your Vote is added to Chairperson");
			}
			if (e.getSource() == b5) {
				g = g + 1;
//        System.out.println(g);
				results.put("g", (Integer.toString(g)));
				results.put("dean", "Dean");
				ps.setInt(1, Integer.parseInt(results.get("g")));
				ps.setString(2, results.get("dean"));
				ps.executeUpdate();
				JOptionPane.showMessageDialog(null, "Your Vote is added to Dean");
			}
			if (e.getSource() == b6) {
				f = f + 1;
				results.put("f", (Integer.toString(f)));
				results.put("coordinator", "Coordinator");
				ps.setInt(1, Integer.parseInt(results.get("f")));
				ps.setString(2, results.get("coordinator"));
				ps.executeUpdate();
				JOptionPane.showMessageDialog(null, "Your Vote is added to Coordinator");
			}
			con.close();
		} catch (Exception exp) {
			System.out.println(exp);
		}
	}





}
