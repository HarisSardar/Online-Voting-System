package onlinevotingsystem;

public class CnicInfo {
	
	public static String cnic = "";

}
