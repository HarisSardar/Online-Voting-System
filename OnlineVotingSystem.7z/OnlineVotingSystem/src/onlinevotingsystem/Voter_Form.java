package onlinevotingsystem;
import javax.swing.*;
import java.awt.*;
public class Voter_Form extends JFrame {
    JLabel message;
    JLabel nameLabel;
    JTextField nameField;
 
    JButton registerButton;
    Container container;
 
    public void RegisterFrame() {
        container = new Container();
        message = new JLabel("Voter Registration Form");
        message.setFont(new Font("Courier", Font.BOLD, 20));
        nameLabel = new JLabel("Name");
        nameField = new JTextField();
                
        registerButton = new JButton("Register");
        container = getContentPane();
        container.setLayout(null);
        setBounds();
        addComponents();
 
    }
 
    public void setBounds() {
        message.setBounds(50, 10, 600, 30);
        nameLabel.setBounds(50, 60, 100, 30);
        nameField.setBounds(130, 60, 200, 30);
 
       
        registerButton.setBounds(130, 550, 200, 30);
    }
 
    public void addComponents() {
        container.add(message);
        container.add(nameLabel);
        container.add(nameField);
        container.add(registerButton);
    }
    

}

