package onlinevotingsystem;

import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.*;
import java.util.ArrayList;

public class candidate_Registration extends JFrame implements ActionListener {
	JTextField tf6;
	JTextField tf1, tf2, tf3, tf4;

	public candidate_Registration() {

		JLabel label1, label2, label3, label4, label5, label6;
		label1 = new JLabel("Candidate Registration Form");
		label1.setBounds(160, 30, 300, 30);

		label2 = new JLabel("Name:");
		label2.setBounds(30, 50, 200, 100);

		label3 = new JLabel("Gender:");
		label3.setBounds(30, 100, 200, 100);

		label4 = new JLabel("Nic Number:");
		label4.setBounds(30, 150, 200, 100);

		label5 = new JLabel("Position:");
		label5.setBounds(30, 200, 200, 100);

		tf1 = new JTextField();
		tf1.setBounds(150, 85, 250, 30);

		tf2 = new JTextField();
		tf2.setBounds(150, 135, 250, 30);

		tf3 = new JTextField(15);
		//final JTextField tf3 = new JTextField(13);
		//tf3.setDocument(new JTextFieldLimit(10));
		tf3.setBounds(150, 185, 250, 30);
		
		tf4 = new JTextField();
		tf4.setBounds(150, 235, 250, 30);

		tf6 = new JTextField();
		tf6.setBounds(150, 350, 250, 30);

		JButton button;
		button = new JButton("Registration");
		button.setBounds(150, 290, 120, 30);

		button.addActionListener(this);

		add(label1);
		add(label2);
		add(label3);
		add(label4);
		add(label5);
		add(tf1);
		add(tf2);
		add(tf3);
		add(tf4);
		add(tf6);
		add(button);
		setSize(450, 500);
		setLayout(null);
		setVisible(true);
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		candidate_Registration registration = new candidate_Registration();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		int cnicLength = tf3.getText().length();
    	if(cnicLength==13) {
    		ArrayList<String> insertData = new ArrayList<String>();
    		try {
    			//String sql = "SELECT * FROM Orders LIMIT 6";
    			Class.forName("com.mysql.cj.jdbc.Driver");
    			// Getting the connection
    			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:5555/test1", "root", "12345");
    			//System.out.println("Connection established......");
    			// Creating a Statement object
    			Statement stmt = con.createStatement();
    			// Retrieving the data
    			String query = " insert into candidate_registration(name, gender, cnic, position, result) values (?, ?, ?, ?, ?);";

    			PreparedStatement preparedStmt = con.prepareStatement(query);
    			insertData.add(tf1.getText());
    			insertData.add(tf2.getText());
    			insertData.add(tf3.getText());
    			insertData.add(tf4.getText());
    			insertData.add(Integer.toString(0));
    			preparedStmt.setString(1, insertData.get(0));
    			preparedStmt.setString(2, insertData.get(1));
    			preparedStmt.setString(3, insertData.get(2));
    			preparedStmt.setString(4, insertData.get(3));

    			preparedStmt.setInt(5, Integer.parseInt(insertData.get(4)));
    			preparedStmt.execute();
    			con.close();
    			tf6.setText("Registration Confirmed");

    		} catch (Exception e2) {
    			System.out.println(e2);
    		}
    	}else {
    		JOptionPane.showMessageDialog(null,"Invalid CNIC number");
    	}
		
	
	}
}
